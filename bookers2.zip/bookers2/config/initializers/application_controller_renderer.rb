# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '7a28552b995cc4e80a023e0c9f0f350b4a692e485adbe44d8914c4d3372d8828c2c40bd24511c4edf7c37a16dad09f65ced41ae905ad16ffee71ba75f6858f6f'